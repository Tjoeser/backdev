<link rel="stylesheet" href="media/styletables.css"></link>
<form method="post" action="db_handler.php">
  <input type="text" name="product_id" placeholder="Product ID..."><br><br>
  <input type="text" name="product_type_code" placeholder="Product Type..."><br><br>
  <input type="text" name="supplier_id" placeholder="Supplier ID..."><br><br>
  <input type="text" name="product_name" placeholder="Product Name..."><br><br>
  <input type="text" name="product_price" placeholder="Product Price..."><br><br>
  <input type="text" name="other_product_details" placeholder="Other Product Details..."><br><br>
  <input type="submit" name="submit" value="submit">
</form>

