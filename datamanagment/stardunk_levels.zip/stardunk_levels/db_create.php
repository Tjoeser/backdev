<form action="db_handler.php "method="post">
  <input type="text" name="product_id" placeholder="Product ID">
  <input type="text" name="product_type_code" placeholder="Product Type">
  <input type="text" name="supplier_id" placeholder="Supplier ID">
  <input type="text" name="product_name" placeholder="Product Name">
  <input type="text" name="product_price" placeholder="Product Price">
  <input type="text" name="other_product_details" placeholder="Other Product Details...">
  <input type="submit" name="submit" value="submit">
</form>