<form action="db_create.php" method="post">
  <input type="submit" name="submit" value="Create new product">
</form>

<?php include "db_return.php";?>