<link rel="stylesheet" href="media/styletables.css"></link>

<?php include "db_functions.php";
controlForm();
// updateProduct($id);
?>

<br>
<br>

<form action="index.php">
<input class="button" type="submit" value="back">
</form>