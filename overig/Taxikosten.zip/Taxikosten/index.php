<link rel="stylesheet" href="form.css">

<?php

$html = "";
$html .= "<form method=\"post\">";
$html .= "<label for=\"aantal_km\">Aantal km:</label><br>";
$html .= "<input type=\"text\" id=\"aantal_km\" name=\"aantal_km\" placeholder=\"Vul het aantal km in...\" value=\"\"><br>";

$html .= "<br>";
$html .= "<label for=\"vertrek_tijd\">Vertrek tijd:</label><br>";
$html .= "<input type=\"time\" id=\"vertrek_tijd\" name=\"vertrek_tijd\" placeholder=\"Vul de vertrek tijd in...\" value=\"\"><br>";

$html .= "<br>";
$html .= "<label for=\"dag\">Dag:</label><br>";
$html .= "<select id=\"dag\" name=\"dag\" placeholder=\"Selecteer de dag...\" value=\"\"><br>";
$html .= "<option value=\"Maandag\">Maandag</option>";
$html .= "<option value=\"Dinsdag\">Dinsdag</option>";
$html .= "<option value=\"Woensdag\">Woensdag</option>";
$html .= "<option value=\"Donderdag\">Donderdag</option>";
$html .= "<option value=\"Vrijdag\">Vrijdag</option>";
$html .= "<option value=\"Zaterdag\">Zaterdag</option>";
$html .= "<option value=\"Zondag\">Zondag</option>";
$html .= "</select>";

$html .= "<br>";
$html .= "<label for=\"opmerking\">Opmerking:</label><br>";
$html .= "<input type=\"text\" id=\"opmerking\" name=\"opmerking\" placeholder=\"Vul een opmerking in...\" value=\"\"><br>";

$html .= "<br>";
$html .= "<input type=\"submit\" name=\"submit\" value=\"Bereken\">";
$html .= "</form>";

echo $html;

if (isset($_REQUEST['submit'])) {
    // Formvelden ophalen
    $aantal_km = $_REQUEST['aantal_km'];
    $vertrek_tijd = $_REQUEST['vertrek_tijd'];
    $dag = $_REQUEST['dag'];
    $opmerking = $_REQUEST['opmerking'];

    // Checken of velden leeg zijn
    if (empty($aantal_km)) {
        echo '\'Aantal km\' is nog leeg<br>';
    }
    if (empty($vertrek_tijd)) {
        echo '\'Vertrek tijd\' is nog leeg<br>';
    }
    if (empty($dag)) {
        echo '\'Dag\' is nog leeg<br>';
    }
    if (empty($opmerking)) {
        echo '\'Opmerking\' is nog leeg<br>';
    } else {

        // Weekend 0.45 tarief
        if ($dag == 'Vrijdag' and $vertrek_tijd > '22:00' or $dag == 'Zaterdag' and $vertrek_tijd < '08:00' || $vertrek_tijd > '18:00' or $dag == 'Zondag' and $vertrek_tijd < '08:00' || $vertrek_tijd > '18:00' or $dag == 'Maandag' and $vertrek_tijd < '07:00') {

            $subtotaal_045 = ($aantal_km * '1') + ($aantal_km * '0.45');
            $subtotaal_045_weekend = $subtotaal_045 * '1.25';
            $subtotaal_045_format_weekend = number_format($subtotaal_045_weekend, 2, ',', '.');

            echo '[DEBUG] Weekend 0.45<br><br>';

            echo "
             Door u gekozen: <br>
             Aantal km: $aantal_km <br>
             vertrek tijd: $vertrek_tijd <br>
             Dag: $dag <br>
             Opmerking: $opmerking<br>
             Subtotaal: €$subtotaal_045_format_weekend
             ";

        } else {

            // Weekend 0.25 tarief
            if ($dag == 'Vrijdag' and $vertrek_tijd > '22:00' or $dag == 'Zaterdag' and $vertrek_tijd > '08:00' || $vertrek_tijd < '18:00' or $dag == 'Zondag' and $vertrek_tijd > '08:00' || $vertrek_tijd < '18:00' or $dag == 'Maandag' and $vertrek_tijd < '07:00') {

                $subtotaal_025 = ($aantal_km * '1') + ($aantal_km * '0.25');
                $subtotaal_025_weekend = $subtotaal_025 * '1.25';
                $subtotaal_025_format_weekend = number_format($subtotaal_025_weekend, 2, ',', '.');

                echo '[DEBUG] Weekend 0.25<br><br>';

                echo "
                 Door u gekozen: <br>
                 Aantal km: $aantal_km <br>
                 Vertrek tijd: $vertrek_tijd <br>
                 Dag: $dag <br>
                 Opmerking: $opmerking<br>
                 Subtotaal: €$subtotaal_025_format_weekend
                 ";
            } else {

                // Normaal 0.45 tarief
                if ($vertrek_tijd < '08:00' || $vertrek_tijd > '18:00') {

                    $subtotaal_045 = ($aantal_km * '1') + ($aantal_km * '0.45');
                    $subtotaal_045_format = number_format($subtotaal_045, 2, ',', '.');

                    echo '[DEBUG] Normaal 0.45<br><br>';

                    echo "
                         Door u gekozen: <br>
                         Aantal km: $aantal_km <br>
                         Vertrek tijd: $vertrek_tijd <br>
                         Dag: $dag<br>
                         Opmerking: $opmerking<br>
                         Subtotaal: €$subtotaal_045_format
                         ";

                } else {

                    // Normaal 0.25 tarief
                    if ($vertrek_tijd > '08:00' || $vertrek_tijd < '18:00') {

                        $subtotaal_025 = ($aantal_km * '1') + ($aantal_km * '0.25');
                        $subtotaal_025_format = number_format($subtotaal_025, 2, ',', '.');

                        echo '[DEBUG] Normaal 0.25<br><br>';

                        echo "
                 Door u gekozen: <br>
                 Aantal km: $aantal_km <br>
                 Vertrek tijd: $vertrek_tijd <br>
                 Dag: $dag <br>
                 Opmerking: $opmerking<br>
                 Subtotaal: €$subtotaal_025_format
                 ";
                    }
                }
            }
        }
    }
}
?>