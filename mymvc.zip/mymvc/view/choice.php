<?php
require 'header.php';
?>
<div class="msg-box">
    <h1>This is a choice page</h1>
    <p>Show the contact</p>
</div>

<?php

echo $content;
require 'footer.php';