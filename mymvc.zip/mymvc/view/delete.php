<?php
require "./header.php";
echo $contacts;

$html = "<a class=\"crudfunctionbutton\" href='index.php'><i class='fa-solid fa-circle-plus'></i> Home</a>";
echo $html;
require "./footer.php";
?>